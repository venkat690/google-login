<?php
	include "db.php";
	require_once "config.php";
	

	if (isset($_SESSION['access_token']))
		$gClient->setAccessToken($_SESSION['access_token']);
	else if (isset($_GET['code'])) {
		$token = $gClient->fetchAccessTokenWithAuthCode($_GET['code']);
		$_SESSION['access_token'] = $token;
	} else {
		header('Location: login.php');
		exit();
	}

	$oAuth = new Google_Service_Oauth2($gClient);
	$userData = $oAuth->userinfo_v2_me->get();

	$id = $userData['id']; 
	$email = $userData['email'];
	$gender = $userData['gender'];
	$picture = $userData['picture'];
	$familyName = $userData['familyName'];
	$givenName = $userData['givenName'];
	
		
			$sql = "INSERT INTO user(id, email, gender, picture, familyName, givenName) 
			VALUES('$id', '$email', '$gender', '$picture', '$familyName', '$givenName')";
			
			
			if(mysqli_query($con,$sql))
			{
				$_SESSION['id'] = mysqli_insert_id($con);
				$_SESSION['email'] = mysqli_insert_id($con);
				//echo "inserted".$_SESSION['id'];
				header('Location: index.php');
				exit();
			}
			else
			{
				echo "not inserted";				
		
			}
	
	
?>